package command;

public interface Command {
    void execute();
}
