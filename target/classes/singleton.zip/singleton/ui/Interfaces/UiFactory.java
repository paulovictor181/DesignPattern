package singleton.ui.Interfaces;

public interface UiFactory {
    UiButton createUiButton();
}
