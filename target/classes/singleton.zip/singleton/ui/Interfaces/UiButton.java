package singleton.ui.Interfaces;

import javax.swing.*;

public interface UiButton {
    JButton getButton();
}
