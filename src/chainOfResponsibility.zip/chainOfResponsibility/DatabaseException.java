package chainOfResponsibility;

public class DatabaseException extends AppException {
    public DatabaseException(String message) { super(message); }
}
