package interpreter;

import java.util.Stack;

public interface ExpressaoRPN {
    void interpretar(Stack<Double> contexto);
}
